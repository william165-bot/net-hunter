# Authentication System for Android APK

This package provides a complete sign-up and sign-in dialog system for your Android application with GitHub backend storage.

## Features

- **Sign Up**: Name, Email, Phone Number, Password
- **Sign In**: Email and Password authentication
- **GitHub Backend**: Uses your GitHub repository to store user credentials
- **Persistent Login**: Users stay logged in using SharedPreferences
- **Password Security**: SHA-256 hashing for passwords
- **Input Validation**: Email and phone number validation

## Package Contents

- `classes2.dex` - Compiled DEX file containing all authentication classes
- `hook.txt` - Smali hook code to add to your app's onCreate method
- `users.json` - Initial empty users database (to be deployed to GitHub)
- `README.md` - This file

## Installation Steps

### 1. Setup GitHub Backend

The `users.json` file needs to be in your GitHub repository at:
```
https://raw.githubusercontent.com/william165-bot/net-hunter/main/users.json
```

This file will store all user credentials securely.

**IMPORTANT**: You need to create a GitHub Personal Access Token:
1. Go to GitHub Settings → Developer settings → Personal access tokens → Tokens (classic)
2. Click "Generate new token (classic)"
3. Give it a name like "APK Auth System"
4. Select scopes: `repo` (full control of private repositories)
5. Generate token and copy it

Then update the token in the DEX file or recompile with your token (see Customization section).

### 2. Add DEX to Your APK

1. Decompile your APK using apktool:
   ```bash
   apktool d your-app.apk
   ```

2. Copy `classes2.dex` to the decompiled app directory

3. Recompile the APK:
   ```bash
   apktool b your-app-folder -o your-app-modded.apk
   ```

4. Sign the APK:
   ```bash
   jarsigner -keystore your-keystore.keystore your-app-modded.apk your-alias
   ```

### 3. Add Hook to onCreate Method

1. Navigate to your main activity's smali file (usually in `smali/com/yourpackage/MainActivity.smali`)

2. Find the `onCreate` method (look for `.method protected onCreate(Landroid/os/Bundle;)V`)

3. Add the hook code right after the `super.onCreate()` call:
   ```smali
   invoke-static {p0}, Llogin/dialog/logindpmods/LoginDialog;->show(Landroid/content/Context;)V
   ```

4. The complete onCreate method should look like:
   ```smali
   .method protected onCreate(Landroid/os/Bundle;)V
       .locals 0
       
       invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V
       
       invoke-static {p0}, Llogin/dialog/logindpmods/LoginDialog;->show(Landroid/content/Context;)V
       
       # rest of your code...
   .end method
   ```

5. Rebuild, sign, and install your APK

## How It Works

### First Launch (New User)
1. Dialog appears with "Sign In" view
2. User clicks "Don't have an account? Sign Up"
3. User enters: Name, Email, Phone Number, Password (min 6 characters)
4. Credentials are validated and sent to GitHub
5. User account is created and stored in `users.json`
6. Dialog disappears and user can access the app
7. User credentials are saved locally (stays logged in)

### Subsequent Launches
1. App checks if user is already logged in
2. If logged in, shows welcome toast and no dialog
3. If not logged in, shows sign-in dialog
4. User enters Email and Password
5. Credentials verified against GitHub data
6. On success, dialog disappears and user accesses app

## Customization

### Update GitHub Token

Edit `GitHubAuthService.java` line 13:
```java
private static final String GITHUB_TOKEN = "YOUR_GITHUB_TOKEN_HERE";
```

Then recompile:
```bash
cd /project/workspace/auth-system
javac -source 1.8 -target 1.8 -cp classes -d classes src/login/dialog/logindpmods/*.java
dalvik-exchange --dex --output=classes2.dex --core-library classes/
```

### Change Repository URL

Edit `GitHubAuthService.java` lines 11-12 to point to your repository:
```java
private static final String GITHUB_RAW_URL = "https://raw.githubusercontent.com/YOUR_USERNAME/YOUR_REPO/main/users.json";
private static final String GITHUB_API_URL = "https://api.github.com/repos/YOUR_USERNAME/YOUR_REPO/contents/users.json";
```

### Modify Dialog Appearance

Edit `LoginDialog.java` to customize colors, text, button styles, etc.

## User Data Structure

Each user in `users.json` has the following structure:
```json
{
  "id": "unique_user_id",
  "name": "John Doe",
  "email": "john@example.com",
  "phoneNumber": "+1234567890",
  "password": "sha256_hashed_password",
  "createdAt": 1703963420000,
  "isActive": true
}
```

## Security Notes

- Passwords are hashed using SHA-256 before storage
- GitHub token should be kept secure
- Consider using environment variables or obfuscation for production
- User data is stored in GitHub private repository (recommended)

## Troubleshooting

### Dialog doesn't appear
- Check that hook is in the correct onCreate method
- Verify classes2.dex is properly included in APK
- Check logcat for errors: `adb logcat | grep LoginDialog`

### Network errors
- Verify GitHub URLs are correct
- Check GitHub token has proper permissions
- Ensure device has internet connection

### Sign up fails
- Check GitHub token validity
- Verify repository exists and is accessible
- Check if users.json exists in repository

## Logout Function

To add a logout button in your app:
```smali
invoke-static {p0}, Llogin/dialog/logindpmods/LoginDialog;->logout(Landroid/content/Context;)V
```

This will clear saved credentials and show the login dialog on next launch.

## Source Files

All source Java files are available in the `src/` directory for reference and customization.

## Support

For issues or questions, please refer to the GitHub repository.

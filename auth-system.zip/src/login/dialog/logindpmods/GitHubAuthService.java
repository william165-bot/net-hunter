package login.dialog.logindpmods;

import android.os.AsyncTask;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;

public class GitHubAuthService {
    private static final String TAG = "GitHubAuthService";
    private static final String GITHUB_RAW_URL = "https://raw.githubusercontent.com/william165-bot/net-hunter/main/users.json";
    private static final String GITHUB_API_URL = "https://api.github.com/repos/william165-bot/net-hunter/contents/users.json";
    private static final String GITHUB_TOKEN = "YOUR_GITHUB_TOKEN";

    public interface AuthCallback {
        void onSuccess(User user);
        void onError(String error);
    }

    public static void signUp(String name, String email, String phoneNumber, String password, final AuthCallback callback) {
        new AsyncTask<Void, Void, String>() {
            User newUser = null;
            String errorMsg = null;

            @Override
            protected String doInBackground(Void... voids) {
                try {
                    List<User> users = fetchUsers();
                    
                    for (User user : users) {
                        if (user.getEmail().equalsIgnoreCase(email)) {
                            errorMsg = "Email already registered";
                            return "ERROR";
                        }
                        if (user.getPhoneNumber().equals(phoneNumber)) {
                            errorMsg = "Phone number already registered";
                            return "ERROR";
                        }
                    }

                    String userId = generateUserId(email);
                    String hashedPassword = hashPassword(password);
                    newUser = new User(userId, name, email, phoneNumber, hashedPassword);
                    
                    users.add(newUser);
                    boolean saved = saveUsers(users);
                    
                    if (saved) {
                        return "SUCCESS";
                    } else {
                        errorMsg = "Failed to save user data";
                        return "ERROR";
                    }
                } catch (Exception e) {
                    Log.e(TAG, "SignUp error", e);
                    errorMsg = "Network error: " + e.getMessage();
                    return "ERROR";
                }
            }

            @Override
            protected void onPostExecute(String result) {
                if ("SUCCESS".equals(result)) {
                    callback.onSuccess(newUser);
                } else {
                    callback.onError(errorMsg != null ? errorMsg : "Unknown error");
                }
            }
        }.execute();
    }

    public static void signIn(String email, String password, final AuthCallback callback) {
        new AsyncTask<Void, Void, String>() {
            User authenticatedUser = null;
            String errorMsg = null;

            @Override
            protected String doInBackground(Void... voids) {
                try {
                    List<User> users = fetchUsers();
                    String hashedPassword = hashPassword(password);
                    
                    for (User user : users) {
                        if (user.getEmail().equalsIgnoreCase(email) && 
                            user.getPassword().equals(hashedPassword) && 
                            user.isActive()) {
                            authenticatedUser = user;
                            return "SUCCESS";
                        }
                    }
                    
                    errorMsg = "Invalid email or password";
                    return "ERROR";
                } catch (Exception e) {
                    Log.e(TAG, "SignIn error", e);
                    errorMsg = "Network error: " + e.getMessage();
                    return "ERROR";
                }
            }

            @Override
            protected void onPostExecute(String result) {
                if ("SUCCESS".equals(result)) {
                    callback.onSuccess(authenticatedUser);
                } else {
                    callback.onError(errorMsg != null ? errorMsg : "Unknown error");
                }
            }
        }.execute();
    }

    private static List<User> fetchUsers() throws Exception {
        List<User> users = new ArrayList<>();
        URL url = new URL(GITHUB_RAW_URL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);

        int responseCode = conn.getResponseCode();
        if (responseCode == 200) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            JSONArray jsonArray = new JSONArray(response.toString());
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonUser = jsonArray.getJSONObject(i);
                User user = new User();
                user.setId(jsonUser.getString("id"));
                user.setName(jsonUser.getString("name"));
                user.setEmail(jsonUser.getString("email"));
                user.setPhoneNumber(jsonUser.getString("phoneNumber"));
                user.setPassword(jsonUser.getString("password"));
                user.setCreatedAt(jsonUser.optLong("createdAt", System.currentTimeMillis()));
                user.setActive(jsonUser.optBoolean("isActive", true));
                users.add(user);
            }
        } else if (responseCode == 404) {
            return users;
        }
        
        conn.disconnect();
        return users;
    }

    private static boolean saveUsers(List<User> users) {
        try {
            JSONArray jsonArray = new JSONArray();
            for (User user : users) {
                JSONObject jsonUser = new JSONObject();
                jsonUser.put("id", user.getId());
                jsonUser.put("name", user.getName());
                jsonUser.put("email", user.getEmail());
                jsonUser.put("phoneNumber", user.getPhoneNumber());
                jsonUser.put("password", user.getPassword());
                jsonUser.put("createdAt", user.getCreatedAt());
                jsonUser.put("isActive", user.isActive());
                jsonArray.put(jsonUser);
            }

            String content = jsonArray.toString(2);
            String base64Content = android.util.Base64.encodeToString(
                content.getBytes("UTF-8"), 
                android.util.Base64.NO_WRAP
            );

            JSONObject requestBody = new JSONObject();
            requestBody.put("message", "Update users data");
            requestBody.put("content", base64Content);
            
            String sha = getCurrentFileSha();
            if (sha != null) {
                requestBody.put("sha", sha);
            }

            URL url = new URL(GITHUB_API_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("PUT");
            conn.setRequestProperty("Authorization", "token " + GITHUB_TOKEN);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            OutputStream os = conn.getOutputStream();
            os.write(requestBody.toString().getBytes("UTF-8"));
            os.close();

            int responseCode = conn.getResponseCode();
            conn.disconnect();
            
            return responseCode == 200 || responseCode == 201;
        } catch (Exception e) {
            Log.e(TAG, "Error saving users", e);
            return false;
        }
    }

    private static String getCurrentFileSha() {
        try {
            URL url = new URL(GITHUB_API_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Authorization", "token " + GITHUB_TOKEN);

            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            JSONObject jsonResponse = new JSONObject(response.toString());
            String sha = jsonResponse.getString("sha");
            conn.disconnect();
            return sha;
        } catch (Exception e) {
            Log.e(TAG, "Error getting file SHA", e);
            return null;
        }
    }

    private static String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes("UTF-8"));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            Log.e(TAG, "Error hashing password", e);
            return password;
        }
    }

    private static String generateUserId(String email) {
        return hashPassword(email + System.currentTimeMillis()).substring(0, 16);
    }
}

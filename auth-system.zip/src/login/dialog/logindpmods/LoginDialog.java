package login.dialog.logindpmods;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class LoginDialog {
    private static final String PREFS_NAME = "AuthPrefs";
    private static final String KEY_USER_EMAIL = "user_email";
    private static final String KEY_USER_NAME = "user_name";
    private static final String KEY_IS_LOGGED_IN = "is_logged_in";

    private static AlertDialog dialog;
    private static boolean isSignUpMode = false;

    public static void show(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        boolean isLoggedIn = prefs.getBoolean(KEY_IS_LOGGED_IN, false);
        
        if (isLoggedIn) {
            String userName = prefs.getString(KEY_USER_NAME, "User");
            Toast.makeText(context, "Welcome back, " + userName + "!", Toast.LENGTH_SHORT).show();
            return;
        }

        LinearLayout mainLayout = new LinearLayout(context);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setPadding(50, 40, 50, 40);
        mainLayout.setBackgroundColor(Color.WHITE);

        TextView titleText = new TextView(context);
        titleText.setText("Sign In");
        titleText.setTextSize(24);
        titleText.setTextColor(Color.parseColor("#333333"));
        titleText.setGravity(Gravity.CENTER);
        titleText.setPadding(0, 0, 0, 30);
        mainLayout.addView(titleText);

        LinearLayout formLayout = new LinearLayout(context);
        formLayout.setOrientation(LinearLayout.VERTICAL);
        formLayout.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        EditText nameInput = createEditText(context, "Full Name", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PERSON_NAME);
        nameInput.setVisibility(View.GONE);
        
        EditText emailInput = createEditText(context, "Email", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        
        EditText phoneInput = createEditText(context, "Phone Number", InputType.TYPE_CLASS_PHONE);
        phoneInput.setVisibility(View.GONE);
        
        EditText passwordInput = createEditText(context, "Password", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        formLayout.addView(nameInput);
        formLayout.addView(emailInput);
        formLayout.addView(phoneInput);
        formLayout.addView(passwordInput);

        mainLayout.addView(formLayout);

        Button submitButton = new Button(context);
        submitButton.setText("Sign In");
        submitButton.setTextColor(Color.WHITE);
        submitButton.setBackgroundColor(Color.parseColor("#4CAF50"));
        LinearLayout.LayoutParams submitParams = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        submitParams.setMargins(0, 20, 0, 10);
        submitButton.setLayoutParams(submitParams);

        Button toggleButton = new Button(context);
        toggleButton.setText("Don't have an account? Sign Up");
        toggleButton.setTextColor(Color.parseColor("#2196F3"));
        toggleButton.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout.LayoutParams toggleParams = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        toggleButton.setLayoutParams(toggleParams);

        mainLayout.addView(submitButton);
        mainLayout.addView(toggleButton);

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setView(mainLayout);
        builder.setCancelable(false);
        dialog = builder.create();

        toggleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isSignUpMode = !isSignUpMode;
                if (isSignUpMode) {
                    titleText.setText("Sign Up");
                    submitButton.setText("Create Account");
                    toggleButton.setText("Already have an account? Sign In");
                    nameInput.setVisibility(View.VISIBLE);
                    phoneInput.setVisibility(View.VISIBLE);
                } else {
                    titleText.setText("Sign In");
                    submitButton.setText("Sign In");
                    toggleButton.setText("Don't have an account? Sign Up");
                    nameInput.setVisibility(View.GONE);
                    phoneInput.setVisibility(View.GONE);
                }
            }
        });

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailInput.getText().toString().trim();
                String password = passwordInput.getText().toString().trim();

                if (email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(context, "Please fill in all required fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (isSignUpMode) {
                    String name = nameInput.getText().toString().trim();
                    String phone = phoneInput.getText().toString().trim();

                    if (name.isEmpty() || phone.isEmpty()) {
                        Toast.makeText(context, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (!isValidEmail(email)) {
                        Toast.makeText(context, "Please enter a valid email", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (!isValidPhone(phone)) {
                        Toast.makeText(context, "Please enter a valid phone number", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (password.length() < 6) {
                        Toast.makeText(context, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    submitButton.setEnabled(false);
                    submitButton.setText("Creating Account...");

                    GitHubAuthService.signUp(name, email, phone, password, new GitHubAuthService.AuthCallback() {
                        @Override
                        public void onSuccess(User user) {
                            SharedPreferences.Editor editor = prefs.edit();
                            editor.putBoolean(KEY_IS_LOGGED_IN, true);
                            editor.putString(KEY_USER_EMAIL, user.getEmail());
                            editor.putString(KEY_USER_NAME, user.getName());
                            editor.apply();

                            Toast.makeText(context, "Account created successfully! Welcome, " + user.getName(), Toast.LENGTH_LONG).show();
                            if (dialog != null) {
                                dialog.dismiss();
                            }
                        }

                        @Override
                        public void onError(String error) {
                            Toast.makeText(context, "Sign up failed: " + error, Toast.LENGTH_LONG).show();
                            submitButton.setEnabled(true);
                            submitButton.setText("Create Account");
                        }
                    });
                } else {
                    if (!isValidEmail(email)) {
                        Toast.makeText(context, "Please enter a valid email", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    submitButton.setEnabled(false);
                    submitButton.setText("Signing In...");

                    GitHubAuthService.signIn(email, password, new GitHubAuthService.AuthCallback() {
                        @Override
                        public void onSuccess(User user) {
                            SharedPreferences.Editor editor = prefs.edit();
                            editor.putBoolean(KEY_IS_LOGGED_IN, true);
                            editor.putString(KEY_USER_EMAIL, user.getEmail());
                            editor.putString(KEY_USER_NAME, user.getName());
                            editor.apply();

                            Toast.makeText(context, "Welcome back, " + user.getName() + "!", Toast.LENGTH_LONG).show();
                            if (dialog != null) {
                                dialog.dismiss();
                            }
                        }

                        @Override
                        public void onError(String error) {
                            Toast.makeText(context, "Sign in failed: " + error, Toast.LENGTH_LONG).show();
                            submitButton.setEnabled(false);
                            submitButton.setText("Sign In");
                        }
                    });
                }
            }
        });

        dialog.show();
    }

    private static EditText createEditText(Context context, String hint, int inputType) {
        EditText editText = new EditText(context);
        editText.setHint(hint);
        editText.setInputType(inputType);
        editText.setPadding(30, 25, 30, 25);
        editText.setTextSize(16);
        editText.setBackgroundColor(Color.parseColor("#F5F5F5"));
        
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 0, 0, 15);
        editText.setLayoutParams(params);
        
        return editText;
    }

    private static boolean isValidEmail(String email) {
        return email != null && email.contains("@") && email.contains(".");
    }

    private static boolean isValidPhone(String phone) {
        return phone != null && phone.length() >= 10 && phone.matches("\\+?[0-9]+");
    }

    public static void logout(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().clear().apply();
        Toast.makeText(context, "Logged out successfully", Toast.LENGTH_SHORT).show();
    }
}
